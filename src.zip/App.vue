<template>
  <div id="app">
    <div>
  <b-navbar background-color="" toggleable="lg" type="light" variant="light">
    <b-navbar-brand><router-link to="/"><img alt="logo" src="./assets/logo.png" contain height="50px"></router-link></b-navbar-brand>
      <b-nav-form>
        <b-form-input size="sm" class="mr-sm-2"></b-form-input>
        <b-button size="sm" class="my-2 my-sm-0" type="submit" variant="outline-success">검색</b-button>
      </b-nav-form>

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

    <b-collapse id="nav-collapse" is-nav>

      <!-- Right aligned nav items -->
      <b-navbar-nav class="ml-auto">
        <b-nav-item-dropdown right>
          <!-- Using 'button-content' slot -->
          <template v-slot:button-content>
            <em>User</em>
          </template>
          <b-dropdown-item href="#">Profile</b-dropdown-item>
          <b-dropdown-item href="#">Sign Out</b-dropdown-item>
        </b-nav-item-dropdown>
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
</div>
    <router-view/>
  </div>
</template>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
