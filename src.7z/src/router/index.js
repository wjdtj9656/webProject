import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import SignUp from '@/components/SignUp.vue'
import Login from '@/components/Login.vue'
import Board from '@/components/board.vue'
import Boards from '@/components/boards.vue'
import ContentDetail from '@/components/ContentDetail'
import Create from '@/components/create.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/signup',
    name: 'signup',
    component: SignUp
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/board',
    name: 'board',
    component: Board
  },
  {
    path: '/boards',
    name: 'Boards',
    component: Boards
  },
  {
    path: '/boards/detail/:contentId',
    name: 'ContentDetail',
    component: ContentDetail
  },
  {
    path: '/boards/create/:contentId?',
    name: 'Create',
    component: Create
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
