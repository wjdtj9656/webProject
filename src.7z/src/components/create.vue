<template>
  <div>
      <div>
    <b-form-group label="메뉴 종류를 선택해주세요. (중복선택 가능)">
      <b-form-checkbox-group
        id="checkbox-group-1"
        v-model="selected"
        :options="options"
        name="flavour-1"
      ></b-form-checkbox-group>
    </b-form-group>
    </div>
    <b-input v-model="subject" placeholder="제목을 입력해 주세요"></b-input>
    <!-- <b-form-textarea
      v-model="context"
      placeholder="내용을 입력해 주세요"
      rows="3"
      max-rows="6"
    ></b-form-textarea> -->
    <div class="editor">
        <editor v-model="context" mode="wysiwyg" />
    </div>
    <b-button @click="updateMode ? updateContent() : uploadContent()">저장</b-button>
    <b-button @click="cancle">취소</b-button>
  </div>
</template>

<style scoped>
.editor{
    margin: auto;
    max-width: 940px;
    width: 100%;
    text-align: left;
}
</style>

<script>
import data from '@/data'
import * as firebase from 'firebase/app'

export default {
  name: 'Create',
  data () {
    return {
      selected: [],
      options: [
        { text: '한식메뉴', value: '한식메뉴' },
        { text: '중식메뉴', value: '중식메뉴' },
        { text: '일식메뉴', value: '일식메뉴' },
        { text: '양식메뉴', value: '양식메뉴' },
        { text: '기타메뉴', value: '기타메뉴' }
      ],
      subject: '',
      context: '',
      userId: 1,
      createdAt: '2019-04-17 11:32:42',
      updatedAt: null,
      updateObject: null,
      updateMode: this.$route.params.contentId > 0
    }
  },
  created () {
    if (this.$route.params.contentId > 0) {
      const contentId = Number(this.$route.params.contentId)
      this.updateObject = data.Content.filter(item => item.content_id === contentId)[0]
      this.subject = this.updateObject.title
      this.context = this.updateObject.context
    }
  },
  methods: {
    uploadContent () {
      let items = data.Content.sort((a, b) => { return b.content_id - a.content_id })
      const contentId = items[0].content_id + 1
      firebase.firestore().collection('board').doc().set({
        content_id: contentId,
        user_id: this.userId,
        title: this.subject,
        context: this.context,
        created_at: this.createdAt,
        updated_at: null
      })
      this.$router.push({
        path: '/boards/'
      })
    },
    updateContent () {
      this.updateObject.title = this.subject
      this.updateObject.context = this.context
      this.$router.push({
        path: '/boards/'
      })
    },
    cancle () {
      this.$router.push({
        path: '/boards/'
      })
    }
  }
}
</script>
