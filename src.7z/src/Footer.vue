<template>
    <div id="footer">
        <p>© Haemeokgo 2019 All Rights Reserved</p>
    </div>
</template>

<style scoped>
#footer{
    width:100%;
    margin: 10px;
    background-color: gray
}
</style>
